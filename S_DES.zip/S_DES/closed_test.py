from itertools import product
import time
import tkinter as tk
from collections import defaultdict
from sdes_core import encrypt


def closed_test(result_text, progress_callback):
    """
    S-DES算法碰撞检测
    检测是否存在多个密钥对同一明文加密得到相同密文的情况
    """
    start_time = time.time()

    # 使用固定的测试明文
    test_plaintext = "10101010"  # 8位二进制测试数据

    # 存储密文到密钥的映射
    cipher_to_keys = defaultdict(list)
    total_keys = 1024  # 2^10 = 1024种可能的密钥
    collision_count = 0
    max_collisions = 0
    max_collision_cipher = ""

    result_text.insert(tk.END, f"开始S-DES算法碰撞检测...\n")
    result_text.insert(tk.END, f"测试明文: {test_plaintext}\n")
    result_text.insert(tk.END, f"密钥空间: {total_keys}个可能的密钥\n")
    result_text.insert(tk.END, "=" * 50 + "\n\n")
    result_text.see(tk.END)

    try:
        # 遍历所有可能的10位密钥
        for i, bits in enumerate(product('01', repeat=10)):
            # 更新进度
            progress = (i / total_keys) * 100
            progress_callback(progress)

            key = ''.join(bits)

            try:
                # 使用当前密钥加密测试明文
                ciphertext = encrypt(test_plaintext, key)

                # 记录密文对应的密钥
                cipher_to_keys[ciphertext].append(key)

                # 如果某个密文有多个密钥对应，说明发生碰撞
                if len(cipher_to_keys[ciphertext]) > 1:
                    collision_count += 1

                    # 更新最大碰撞信息
                    if len(cipher_to_keys[ciphertext]) > max_collisions:
                        max_collisions = len(cipher_to_keys[ciphertext])
                        max_collision_cipher = ciphertext

                # 定期显示进度信息
                if i % 100 == 0 and i > 0:
                    result_text.insert(tk.END, f"已处理 {i}/{total_keys} 个密钥...\n")
                    result_text.see(tk.END)

            except Exception as e:
                result_text.insert(tk.END, f"处理密钥 {key} 时出错: {str(e)}\n")
                result_text.see(tk.END)
                continue

        # 计算统计信息
        end_time = time.time()
        elapsed_time = end_time - start_time

        # 分析结果
        unique_ciphers = len(cipher_to_keys)
        total_collisions = sum(len(keys) - 1 for keys in cipher_to_keys.values() if len(keys) > 1)

        # 输出详细分析结果
        result_text.insert(tk.END, "\n" + "=" * 50 + "\n")
        result_text.insert(tk.END, "S-DES算法碰撞检测结果\n")
        result_text.insert(tk.END, "=" * 50 + "\n\n")

        result_text.insert(tk.END, f"统计摘要:\n")
        result_text.insert(tk.END, f"- 总处理时间: {elapsed_time:.6f}秒\n")
        result_text.insert(tk.END, f"- 测试明文: {test_plaintext}\n")
        result_text.insert(tk.END, f"- 总密钥数: {total_keys}\n")
        result_text.insert(tk.END, f"- 唯一密文数: {unique_ciphers}\n")
        result_text.insert(tk.END, f"- 理论最小密文数: {total_keys // 256 if total_keys >= 256 else 1}\n")
        result_text.insert(tk.END, f"- 总碰撞次数: {total_collisions}\n")
        result_text.insert(tk.END, f"- 发生碰撞的密文数量: {collision_count}\n")
        result_text.insert(tk.END, f"- 最大碰撞次数: {max_collisions - 1} (对应 {max_collisions} 个密钥)\n\n")

        # 计算碰撞率
        collision_rate = (collision_count / unique_ciphers * 100) if unique_ciphers > 0 else 0
        result_text.insert(tk.END, f"碰撞分析:\n")
        result_text.insert(tk.END, f"- 碰撞率: {collision_rate:.2f}% 的密文存在密钥碰撞\n")
        result_text.insert(tk.END, f"- 密钥利用率: {(unique_ciphers / total_keys * 100):.2f}%\n\n")

        # 显示碰撞详情
        if collision_count > 0:
            result_text.insert(tk.END, f"碰撞详情:\n")

            # 显示最大碰撞的详细信息
            if max_collision_cipher:
                result_text.insert(tk.END,
                                   f"最大碰撞 - 密文 '{max_collision_cipher}' 对应以下 {max_collisions} 个密钥:\n")
                for key in cipher_to_keys[max_collision_cipher]:
                    result_text.insert(tk.END, f"  - {key}\n")
                result_text.insert(tk.END, "\n")

            # 显示所有存在碰撞的密文（限制显示数量）
            collision_ciphers = [(cipher, keys) for cipher, keys in cipher_to_keys.items() if len(keys) > 1]
            collision_ciphers.sort(key=lambda x: len(x[1]), reverse=True)

            result_text.insert(tk.END, f"所有碰撞情况 (显示前10个):\n")
            for i, (cipher, keys) in enumerate(collision_ciphers[:10]):
                result_text.insert(tk.END, f"{i + 1}. 密文 '{cipher}': {len(keys)} 个密钥\n")

            if len(collision_ciphers) > 10:
                result_text.insert(tk.END, f"... 还有 {len(collision_ciphers) - 10} 个碰撞未显示\n")

        else:
            result_text.insert(tk.END, "未发现密钥碰撞！\n\n")

        # 安全性评估
        result_text.insert(tk.END, f"安全性评估:\n")
        if collision_count == 0:
            result_text.insert(tk.END, "✓ 优秀：未发现密钥碰撞，算法具有良好的密钥唯一性\n")
        elif collision_rate < 5:
            result_text.insert(tk.END, "✓ 良好：碰撞率较低，算法密钥特性较好\n")
        elif collision_rate < 15:
            result_text.insert(tk.END, "⚠ 一般：存在一定碰撞，但仍在可接受范围内\n")
        else:
            result_text.insert(tk.END, "✗ 较差：碰撞率较高，可能存在安全性问题\n")

        # 理论分析
        result_text.insert(tk.END, f"\n理论分析:\n")
        result_text.insert(tk.END, f"- 理想情况下，每个密钥应产生唯一的密文\n")
        result_text.insert(tk.END, f"- 实际密文空间: 2^8 = 256 种可能\n")
        result_text.insert(tk.END, f"- 密钥空间: 2^10 = 1024 种可能\n")
        result_text.insert(tk.END, f"- 根据鸽巢原理，必然存在密钥碰撞\n")
        result_text.insert(tk.END, f"- 期望碰撞率: {(1 - 256 / 1024) * 100:.1f}%\n")

    except Exception as e:
        result_text.insert(tk.END, f"\n碰撞检测过程中发生错误: {str(e)}\n")
        result_text.see(tk.END)

    result_text.see(tk.END)


def multi_plaintext_test(result_text, progress_callback):
    """
    多明文碰撞检测 - 使用多个测试明文进行更全面的分析
    """
    test_plaintexts = [
        "00000000",  # 全0
        "11111111",  # 全1
        "10101010",  # 交替1/0
        "01010101",  # 交替0/1
        "11001100",  # 重复模式
        "00110011",  # 重复模式
        "10011001",  # 随机模式
        "01100110"  # 随机模式
    ]

    result_text.insert(tk.END, "开始多明文碰撞检测...\n")
    result_text.insert(tk.END, f"使用 {len(test_plaintexts)} 个测试明文\n\n")

    overall_results = []

    for idx, plaintext in enumerate(test_plaintexts):
        result_text.insert(tk.END, f"测试明文 {idx + 1}: {plaintext}\n")

        cipher_to_keys = defaultdict(list)
        total_keys = 1024

        # 对每个明文进行碰撞检测
        for i, bits in enumerate(product('01', repeat=10)):
            progress = ((idx * total_keys + i) / (len(test_plaintexts) * total_keys)) * 100
            progress_callback(progress)

            key = ''.join(bits)
            try:
                ciphertext = encrypt(plaintext, key)
                cipher_to_keys[ciphertext].append(key)
            except:
                continue

        # 统计该明文的碰撞情况
        unique_ciphers = len(cipher_to_keys)
        collisions = sum(1 for keys in cipher_to_keys.values() if len(keys) > 1)
        collision_rate = (collisions / unique_ciphers * 100) if unique_ciphers > 0 else 0

        overall_results.append({
            'plaintext': plaintext,
            'unique_ciphers': unique_ciphers,
            'collisions': collisions,
            'collision_rate': collision_rate
        })

        result_text.insert(tk.END,
                           f"  - 唯一密文: {unique_ciphers}, 碰撞: {collisions}, 碰撞率: {collision_rate:.2f}%\n")
        result_text.see(tk.END)

    # 输出多明文测试总结
    result_text.insert(tk.END, "\n" + "=" * 50 + "\n")
    result_text.insert(tk.END, "多明文碰撞检测总结\n")
    result_text.insert(tk.END, "=" * 50 + "\n")

    avg_collision_rate = sum(r['collision_rate'] for r in overall_results) / len(overall_results)
    result_text.insert(tk.END, f"平均碰撞率: {avg_collision_rate:.2f}%\n")

    # 找出碰撞最多和最少的明文
    max_collision = max(overall_results, key=lambda x: x['collision_rate'])
    min_collision = min(overall_results, key=lambda x: x['collision_rate'])

    result_text.insert(tk.END,
                       f"最高碰撞率: {max_collision['collision_rate']:.2f}% (明文: {max_collision['plaintext']})\n")
    result_text.insert(tk.END,
                       f"最低碰撞率: {min_collision['collision_rate']:.2f}% (明文: {min_collision['plaintext']})\n")

    result_text.see(tk.END)