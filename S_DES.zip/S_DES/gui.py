import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import threading
from sdes_core import encrypt, decrypt
from ascii_processor import encrypt_ascii, decrypt_ascii
from brute_force import brute_force_crack
from closed_test import closed_test

class SDesGUI:
    #初始化
    def __init__(self, root):
        self.root = root
        self.root.title("S-DES 加密算法工具")
        self.root.geometry("850x650")
        self.root.minsize(800, 600)
        
        # 设置样式
        self.setup_styles()
        
        # 创建主框架
        self.main_frame = ttk.Frame(root, padding="20")
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建标题
        self.create_title()
        
        # 创建标签页控件
        self.create_tabs()
        
        # 初始化各标签页内容
        self.init_basic_tab()
        self.init_ascii_tab()
        self.init_brute_tab()
        self.init_test_tab()
        
        # 状态变量
        self.is_processing = False

    def setup_styles(self):
        style = ttk.Style()
        
        # 配置整体字体
        style.configure(".", font=("Segoe UI", 10))
        
        # 标题样式
        style.configure("Title.TLabel", font=("Segoe UI", 16, "bold"), 
                       foreground="#2c3e50", padding=(0, 10, 0, 20))
        
        # 标签页标题样式
        style.configure("TNotebook.Tab", font=("Segoe UI", 10, "bold"), 
                       padding=(15, 5), foreground="#34495e")
        style.map("TNotebook.Tab", 
                 background=[("selected", "#ecf0f1"), ("active", "#f8f9fa")],
                 foreground=[("selected", "#2980b9")])
        
        # 按钮样式
        style.configure("TButton", font=("Segoe UI", 10), padding=(10, 5))
        style.map("TButton",
                 background=[("active", "#3498db"), ("pressed", "#2980b9")],
                 foreground=[("active", "white"), ("pressed", "white")])
        
        # 卡片式容器样式
        style.configure("Card.TFrame", background="white", relief="flat",
                       padding=15)
        style.configure("Section.TLabel", font=("Segoe UI", 12, "bold"),
                       foreground="#2980b9", padding=(0, 10, 0, 10))

    def create_title(self):
        title_frame = ttk.Frame(self.main_frame)
        title_frame.pack(fill=tk.X, pady=(0, 15))
        
        ttk.Label(title_frame, text="S-DES 加密算法工具", 
                 style="Title.TLabel").pack(anchor=tk.W)
        
        # 分隔线
        ttk.Separator(self.main_frame).pack(fill=tk.X, pady=(0, 20))

    def create_tabs(self):
        self.tab_control = ttk.Notebook(self.main_frame)
        
        # 创建各个标签页
        self.basic_tab = ttk.Frame(self.tab_control)
        self.ascii_tab = ttk.Frame(self.tab_control)
        self.brute_tab = ttk.Frame(self.tab_control)
        self.test_tab = ttk.Frame(self.tab_control)
        
        # 添加标签页
        self.tab_control.add(self.basic_tab, text="基础加解密")
        self.tab_control.add(self.ascii_tab, text="字符串处理")
        self.tab_control.add(self.brute_tab, text="暴力破解")
        self.tab_control.add(self.test_tab, text="算法分析")
        
        self.tab_control.pack(fill=tk.BOTH, expand=True)

    def init_basic_tab(self):
        # 创建卡片式容器
        card = ttk.Frame(self.basic_tab, style="Card.TFrame")
        card.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # 标题
        ttk.Label(card, text="二进制数据加解密", style="Section.TLabel").grid(
            row=0, column=0, columnspan=2, sticky=tk.W)
        
        # 输入区域
        input_frame = ttk.Frame(card)
        input_frame.grid(row=1, column=0, columnspan=2, sticky=tk.W+tk.E, pady=10)
        
        # 明文/密文输入
        ttk.Label(input_frame, text="8位输入 (二进制):", width=20).grid(
            row=0, column=0, padx=10, pady=10, sticky=tk.W)
        self.basic_input = ttk.Entry(input_frame, width=30)
        self.basic_input.grid(row=0, column=1, padx=10, pady=10)

        # 密钥输入
        ttk.Label(input_frame, text="10位密钥 (二进制):", width=20).grid(
            row=1, column=0, padx=10, pady=10, sticky=tk.W)
        self.basic_key = ttk.Entry(input_frame, width=30)
        self.basic_key.grid(row=1, column=1, padx=10, pady=10)

        # 输出区域
        ttk.Label(input_frame, text="输出结果:", width=20).grid(
            row=2, column=0, padx=10, pady=10, sticky=tk.W)
        self.basic_output_var = tk.StringVar()
        self.basic_output = ttk.Entry(
            input_frame, textvariable=self.basic_output_var, 
            state="readonly", width=30)
        self.basic_output.grid(row=2, column=1, padx=10, pady=10)

        # 按钮区域
        btn_frame = ttk.Frame(card)
        btn_frame.grid(row=2, column=0, columnspan=2, pady=20)
        
        ttk.Button(btn_frame, text="加密", command=self.basic_encrypt, 
                  width=15).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="解密", command=self.basic_decrypt, 
                  width=15).pack(side=tk.LEFT, padx=10)

        # 说明区域
        note_frame = ttk.Frame(card)
        note_frame.grid(row=3, column=0, columnspan=2, sticky=tk.W+tk.E, pady=10)
        
        ttk.Label(note_frame, text="交叉测试说明:", font=("Segoe UI", 10, "bold")).pack(
            anchor=tk.W, pady=(0, 5))
        cross_note = "• 使用相同的密钥和明文，不同实现应得到相同密文\n" \
                     "• 将此程序加密的密文用其他符合标准的程序解密，应得到原始明文"
        ttk.Label(note_frame, text=cross_note, justify=tk.LEFT, wraplength=600).pack(
            anchor=tk.W)

        input_frame.columnconfigure(1, weight=1)
        note_frame.columnconfigure(0, weight=1)
        card.columnconfigure(0, weight=1)
        card.columnconfigure(1, weight=1)

    def init_ascii_tab(self):
        card = ttk.Frame(self.ascii_tab, style="Card.TFrame")
        card.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # 标题
        ttk.Label(card, text="ASCII字符串加解密", style="Section.TLabel").grid(
            row=0, column=0, columnspan=2, sticky=tk.W)
        
        # 输入区域
        input_frame = ttk.Frame(card)
        input_frame.grid(row=1, column=0, columnspan=2, sticky=tk.N+tk.S+tk.E+tk.W, pady=10)
        
        # 文本输入
        ttk.Label(input_frame, text="输入文本:").grid(
            row=0, column=0, padx=10, pady=10, sticky=tk.NW)
        self.ascii_input = scrolledtext.ScrolledText(input_frame, width=40, height=6)
        self.ascii_input.grid(row=0, column=1, padx=10, pady=10, sticky=tk.N+tk.S+tk.E+tk.W)

        # 密钥输入
        ttk.Label(input_frame, text="10位密钥 (二进制):").grid(
            row=1, column=0, padx=10, pady=10, sticky=tk.W)
        self.ascii_key = ttk.Entry(input_frame, width=30)
        self.ascii_key.grid(row=1, column=1, padx=10, pady=10, sticky=tk.W)

        # 输出区域
        ttk.Label(input_frame, text="输出结果:").grid(
            row=2, column=0, padx=10, pady=10, sticky=tk.NW)
        self.ascii_output = scrolledtext.ScrolledText(input_frame, width=40, height=6, state="disabled")
        self.ascii_output.grid(row=2, column=1, padx=10, pady=10, sticky=tk.N+tk.S+tk.E+tk.W)

        # 按钮区域
        btn_frame = ttk.Frame(card)
        btn_frame.grid(row=2, column=0, columnspan=2, pady=20)
        
        ttk.Button(btn_frame, text="加密字符串", command=self.ascii_encrypt, 
                  width=15).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="解密字符串", command=self.ascii_decrypt, 
                  width=15).pack(side=tk.LEFT, padx=10)

        input_frame.rowconfigure(0, weight=1)
        input_frame.rowconfigure(2, weight=1)
        input_frame.columnconfigure(1, weight=1)
        card.columnconfigure(0, weight=1)
        card.columnconfigure(1, weight=1)
        card.rowconfigure(1, weight=1)

    def init_brute_tab(self):
        card = ttk.Frame(self.brute_tab, style="Card.TFrame")
        card.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # 标题
        ttk.Label(card, text="密钥暴力破解", style="Section.TLabel").grid(
            row=0, column=0, columnspan=2, sticky=tk.W)
        
        # 破解模式选择
        mode_frame = ttk.Frame(card)
        mode_frame.grid(row=1, column=0, columnspan=2, sticky=tk.W, pady=10)
        
        ttk.Label(mode_frame, text="破解模式:").pack(side=tk.LEFT, padx=10)
        self.brute_mode = tk.StringVar(value="binary")
        mode_combobox = ttk.Combobox(mode_frame, textvariable=self.brute_mode, 
                                    values=["binary", "ascii"], state="readonly", width=10)
        mode_combobox.pack(side=tk.LEFT, padx=10)
        mode_combobox.bind("<<ComboboxSelected>>", self.update_brute_inputs)
        
        # 输入区域
        self.brute_input_frame = ttk.Frame(card)
        self.brute_input_frame.grid(row=2, column=0, columnspan=2, sticky=tk.W+tk.E, pady=10)
        
        # 二进制模式输入
        self.binary_inputs = ttk.Frame(self.brute_input_frame)
        
        ttk.Label(self.binary_inputs, text="已知明文 (8位二进制):", width=25).grid(
            row=0, column=0, padx=10, pady=10, sticky=tk.W)
        self.brute_plaintext_bin = ttk.Entry(self.binary_inputs, width=30)
        self.brute_plaintext_bin.grid(row=0, column=1, padx=10, pady=10)

        ttk.Label(self.binary_inputs, text="对应密文 (8位二进制):", width=25).grid(
            row=1, column=0, padx=10, pady=10, sticky=tk.W)
        self.brute_ciphertext_bin = ttk.Entry(self.binary_inputs, width=30)
        self.brute_ciphertext_bin.grid(row=1, column=1, padx=10, pady=10)
        
        # ASCII模式输入
        self.ascii_inputs = ttk.Frame(self.brute_input_frame)
        
        ttk.Label(self.ascii_inputs, text="已知明文 (ASCII):", width=25).grid(
            row=0, column=0, padx=10, pady=10, sticky=tk.NW)
        self.brute_plaintext_ascii = scrolledtext.ScrolledText(self.ascii_inputs, width=30, height=3)
        self.brute_plaintext_ascii.grid(row=0, column=1, padx=10, pady=10)

        ttk.Label(self.ascii_inputs, text="对应密文 (ASCII):", width=25).grid(
            row=1, column=0, padx=10, pady=10, sticky=tk.NW)
        self.brute_ciphertext_ascii = scrolledtext.ScrolledText(self.ascii_inputs, width=30, height=3)
        self.brute_ciphertext_ascii.grid(row=1, column=1, padx=10, pady=10)
        
        # 默认显示二进制输入
        self.update_brute_inputs(None)

        # 进度条
        self.brute_progress = ttk.Progressbar(card, orient="horizontal", 
                                             length=100, mode="determinate")
        self.brute_progress.grid(row=3, column=0, columnspan=2, padx=10, pady=10, 
                                sticky=tk.W+tk.E)

        # 结果区域
        result_frame = ttk.Frame(card)
        result_frame.grid(row=4, column=0, columnspan=2, sticky=tk.N+tk.S+tk.E+tk.W, pady=10)
        
        ttk.Label(result_frame, text="破解结果:").pack(anchor=tk.W, padx=10, pady=(0, 10))
        self.brute_result = scrolledtext.ScrolledText(result_frame, width=60, height=10)
        self.brute_result.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # 按钮
        ttk.Button(card, text="开始暴力破解", command=self.start_brute_force).grid(
            row=5, column=0, columnspan=2, pady=10)

        # 说明
        note_frame = ttk.Frame(card)
        note_frame.grid(row=6, column=0, columnspan=2, sticky=tk.W+tk.E, pady=10)
        
        brute_note = "S-DES有10位密钥，共2^10=1024种可能。\n" \
                     "二进制模式：输入8位二进制明文和密文对\n" \
                     "ASCII模式：输入ASCII字符串明文和对应的加密字符串"
        ttk.Label(note_frame, text=brute_note, justify=tk.LEFT, wraplength=600).pack(
            anchor=tk.W, padx=10)

        # 配置权重
        self.binary_inputs.columnconfigure(1, weight=1)
        self.ascii_inputs.columnconfigure(1, weight=1)
        self.brute_input_frame.columnconfigure(0, weight=1)
        result_frame.rowconfigure(0, weight=1)
        card.columnconfigure(0, weight=1)
        card.columnconfigure(1, weight=1)
        card.rowconfigure(4, weight=1)

    def update_brute_inputs(self, event):
        # 隐藏所有输入区域
        for widget in self.binary_inputs.winfo_children():
            widget.grid_remove()
        for widget in self.ascii_inputs.winfo_children():
            widget.grid_remove()
        self.binary_inputs.pack_forget()
        self.ascii_inputs.pack_forget()
        
        # 根据选择显示对应的输入区域
        if self.brute_mode.get() == "binary":
            self.binary_inputs.pack(fill=tk.X, expand=True)
            for widget in self.binary_inputs.winfo_children():
                widget.grid()
        else:  # ascii模式
            self.ascii_inputs.pack(fill=tk.X, expand=True)
            for widget in self.ascii_inputs.winfo_children():
                widget.grid()

    def start_brute_force(self):
        if self.is_processing:
            messagebox.showinfo("提示", "正在处理中，请稍候...")
            return
        
        # 根据选择的模式获取输入并验证
        mode = self.brute_mode.get()
        valid = False
        
        if mode == "binary":
            # 二进制模式验证
            plaintext = self.brute_plaintext_bin.get().strip()
            ciphertext = self.brute_ciphertext_bin.get().strip()
            
            if len(plaintext) != 8 or not all(c in "01" for c in plaintext):
                messagebox.showerror("输入错误", "请输入8位二进制数作为明文！")
                return
            if len(ciphertext) != 8 or not all(c in "01" for c in ciphertext):
                messagebox.showerror("输入错误", "请输入8位二进制数作为密文！")
                return
            valid = True
            
        else:  # ASCII模式
            plaintext = self.brute_plaintext_ascii.get("1.0", tk.END).strip()
            ciphertext = self.brute_ciphertext_ascii.get("1.0", tk.END).strip()
            
            if not plaintext:
                messagebox.showerror("输入错误", "请输入明文字符串！")
                return
            if not ciphertext:
                messagebox.showerror("输入错误", "请输入密文字符串！")
                return
            # 检查明文和密文长度是否相同
            if len(plaintext) != len(ciphertext):
                messagebox.showerror("输入错误", "明文和密文的长度必须相同！")
                return
            valid = True
        
        if valid:
            self.is_processing = True
            self.brute_progress["value"] = 0
            self.brute_result.delete(1.0, tk.END)
            self.brute_result.insert(tk.END, f"开始{('二进制' if mode == 'binary' else 'ASCII字符串')}暴力破解...\n\n")
            
            # 定义进度更新回调
            def update_progress(progress):
                self.brute_progress["value"] = progress
                self.root.update_idletasks()
            
            # 定义完成回调
            def on_complete():
                self.is_processing = False
                self.brute_progress["value"] = 100
            
            # 在新线程中执行暴力破解
            thread = threading.Thread(target=self.run_brute_force, 
                                     args=(mode, plaintext, ciphertext, update_progress, on_complete))
            thread.daemon = True
            thread.start()

    def run_brute_force(self, mode, plaintext, ciphertext, progress_callback, complete_callback):
        try:
            brute_force_crack(mode, plaintext, ciphertext, self.brute_result, progress_callback)
        finally:
            complete_callback()
            #self.root.after(0, lambda: self.brute_result.insert(tk.END, "\n破解完成！"))

    def init_test_tab(self):
        card = ttk.Frame(self.test_tab, style="Card.TFrame")
        card.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # 标题
        ttk.Label(card, text="S-DES算法特性分析", style="Section.TLabel").grid(
            row=0, column=0, columnspan=2, sticky=tk.W)
        
        # 结果区域
        result_frame = ttk.Frame(card)
        result_frame.grid(row=1, column=0, columnspan=2, sticky=tk.N+tk.S+tk.E+tk.W, pady=10)
        
        ttk.Label(result_frame, text="分析结果:").pack(anchor=tk.W, padx=10, pady=(0, 10))
        self.test_result = scrolledtext.ScrolledText(result_frame, width=60, height=12)
        self.test_result.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # 进度条
        self.test_progress = ttk.Progressbar(card, orient="horizontal", 
                                           length=100, mode="determinate")
        self.test_progress.grid(row=2, column=0, columnspan=2, padx=10, pady=10, 
                              sticky=tk.W+tk.E)

        # 按钮
        ttk.Button(card, text="开始算法分析", command=self.start_closed_test).grid(
            row=3, column=0, columnspan=2, pady=10)

        # 说明
        note_frame = ttk.Frame(card)
        note_frame.grid(row=4, column=0, columnspan=2, sticky=tk.W+tk.E, pady=10)
        
        test_note = "算法分析将检测S-DES的密钥特性：\n" \
                   "1. 是否存在多个密钥对同一明文加密得到相同密文\n" \
                   "2. 统计密钥碰撞的次数\n" \
                   "测试将遍历所有可能的1024个密钥，对固定明文进行加密分析。"
        ttk.Label(note_frame, text=test_note, justify=tk.LEFT, wraplength=600).pack(
            anchor=tk.W, padx=10)

        # 配置权重
        result_frame.rowconfigure(0, weight=1)
        card.columnconfigure(0, weight=1)
        card.columnconfigure(1, weight=1)
        card.rowconfigure(1, weight=1)

    # ---------------------- 事件处理函数 ----------------------
    def basic_encrypt(self):
        input_text = self.basic_input.get().strip()
        key = self.basic_key.get().strip()
        
        if len(input_text) != 8 or not all(c in "01" for c in input_text):
            messagebox.showerror("输入错误", "请输入8位二进制数作为输入！")
            return
        if len(key) != 10 or not all(c in "01" for c in key):
            messagebox.showerror("输入错误", "请输入10位二进制数作为密钥！")
            return
        
        try:
            result = encrypt(input_text, key)
            self.basic_output_var.set(result)
        except Exception as e:
            messagebox.showerror("错误", f"加密失败: {str(e)}")

    def basic_decrypt(self):
        input_text = self.basic_input.get().strip()
        key = self.basic_key.get().strip()
        
        if len(input_text) != 8 or not all(c in "01" for c in input_text):
            messagebox.showerror("输入错误", "请输入8位二进制数作为输入！")
            return
        if len(key) != 10 or not all(c in "01" for c in key):
            messagebox.showerror("输入错误", "请输入10位二进制数作为密钥！")
            return
        
        try:
            result = decrypt(input_text, key)
            self.basic_output_var.set(result)
        except Exception as e:
            messagebox.showerror("错误", f"解密失败: {str(e)}")

    def ascii_encrypt(self):
        text = self.ascii_input.get("1.0", tk.END).strip()
        key = self.ascii_key.get().strip()
        
        if not text:
            messagebox.showerror("输入错误", "请输入要加密的文本！")
            return
        if len(key) != 10 or not all(c in "01" for c in key):
            messagebox.showerror("输入错误", "请输入10位二进制数作为密钥！")
            return
        
        try:
            result = encrypt_ascii(text, key)
            self.ascii_output.config(state="normal")
            self.ascii_output.delete("1.0", tk.END)
            self.ascii_output.insert("1.0", result)
            self.ascii_output.config(state="disabled")
        except Exception as e:
            messagebox.showerror("错误", f"加密失败: {str(e)}")

    def ascii_decrypt(self):
        text = self.ascii_input.get("1.0", tk.END).strip()
        key = self.ascii_key.get().strip()
        
        if not text:
            messagebox.showerror("输入错误", "请输入要解密的文本！")
            return
        if len(key) != 10 or not all(c in "01" for c in key):
            messagebox.showerror("输入错误", "请输入10位二进制数作为密钥！")
            return
        
        try:
            result = decrypt_ascii(text, key)
            self.ascii_output.config(state="normal")
            self.ascii_output.delete("1.0", tk.END)
            self.ascii_output.insert("1.0", result)
            self.ascii_output.config(state="disabled")
        except Exception as e:
            messagebox.showerror("错误", f"解密失败: {str(e)}")
    def start_closed_test(self):
        if self.is_processing:
            messagebox.showinfo("提示", "正在处理中，请稍候...")
            return
            
        self.is_processing = True
        self.test_progress["value"] = 0
        self.test_result.delete(1.0, tk.END)
        self.test_result.insert(tk.END, "开始算法分析...\n\n")
        
        # 定义进度更新回调
        def update_progress(progress):
            self.test_progress["value"] = progress
            self.root.update_idletasks()
        
        # 定义完成回调
        def on_complete():
            self.is_processing = False
            self.test_progress["value"] = 100
        
        # 在新线程中执行测试
        thread = threading.Thread(target=self.run_closed_test, 
                                 args=(update_progress, on_complete))
        thread.daemon = True
        thread.start()

    def run_closed_test(self, progress_callback, complete_callback):
        try:
            closed_test(self.test_result, progress_callback)
        finally:
            complete_callback()
            self.root.after(0, lambda: self.test_result.insert(tk.END, "\n分析完成！"))
    