# main.py
# S-DES程序入口
import tkinter as tk
from gui import SDesGUI

def main():
    root = tk.Tk()
    app = SDesGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
    